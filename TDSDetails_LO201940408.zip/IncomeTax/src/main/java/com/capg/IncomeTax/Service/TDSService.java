package com.capg.IncomeTax.Service;

import com.capg.IncomeTax.model.TDSDetails;

public interface TDSService {
	TDSDetails getById(int id);


}
