package com.capg.IncomeTax.Dao;

import com.capg.IncomeTax.model.TDSDetails;

public interface TDSDao {

	TDSDetails getById(int id);

}
